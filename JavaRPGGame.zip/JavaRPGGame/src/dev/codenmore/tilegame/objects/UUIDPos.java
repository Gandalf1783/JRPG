package dev.codenmore.tilegame.objects;

public class UUIDPos {
    public Pos p;
    public String uuid;
}
