package dev.codenmore.tilegame.objects;

public class BasicResponse {
    public String text;
    public String data;
}
