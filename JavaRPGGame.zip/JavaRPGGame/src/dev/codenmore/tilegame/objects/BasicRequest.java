package dev.codenmore.tilegame.objects;

public class BasicRequest {
    public String text;
    public String data;
}
