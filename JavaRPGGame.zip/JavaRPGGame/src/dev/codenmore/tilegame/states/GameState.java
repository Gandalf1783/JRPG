package dev.codenmore.tilegame.states;

import java.awt.*;

import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.gfx.Text;
import dev.codenmore.tilegame.worlds.World;

public class GameState extends State {
	
	private World world;
	private Boolean displayDebug = false;
	public GameState(Handler handler){
		super(handler);
		world = new World(handler);
		world.loadWorld( "res/worlds/world1.txt");
		handler.setWorld(world);
	}
	
	@Override
	public void tick() {
		world.tick();
	}

	@Override
	public void render(Graphics g) {
		world.render(g);
		if(handler.getKeyManager().debug) {
			try {
				displayDebug = !displayDebug;
				Thread.sleep(250);
			} catch (InterruptedException e) {
			}
		}

		if(displayDebug) {
			int x = (int) world.getEntityManager().getPlayer().getX();
			int y = (int) world.getEntityManager().getPlayer().getY();
			int width = world.getEntityManager().getPlayer().getWidth();
			int height = world.getEntityManager().getPlayer().getHeight();
			Text.drawString(g, "X:  " + x, 10, 12, false, Color.WHITE, Assets.font15);
			Text.drawString(g, "Y:  " + y, 10, 24, false, Color.WHITE, Assets.font15);
			Text.drawString(g, "HP: " +world.getEntityManager().getPlayer().getHealth(), 10, 36, false, Color.WHITE, Assets.font15);
			Text.drawString(g, "COLIDES: "+world.getEntityManager().getPlayer().checkEntityCollisions(world.getEntityManager().getPlayer().getxMove(), world.getEntityManager().getPlayer().getyMove()), 10, 48, false, Color.WHITE, Assets.font15);
			g.drawRect(x  - (int) world.getHandler().getGameCamera().getxOffset(), y - (int) world.getHandler().getGameCamera().getyOffset(), width, height );
		}
	}

}
