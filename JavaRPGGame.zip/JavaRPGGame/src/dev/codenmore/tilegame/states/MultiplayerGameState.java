package dev.codenmore.tilegame.states;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.Client;
import dev.codenmore.tilegame.Game;
import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.Entity;
import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.gfx.Text;
import dev.codenmore.tilegame.mpListener.EntityPKG;
import dev.codenmore.tilegame.mpListener.Listener;
import dev.codenmore.tilegame.objects.*;
import dev.codenmore.tilegame.threads.NetworkingThread;
import dev.codenmore.tilegame.worlds.RemoteWorld;
import javafx.geometry.Bounds;

import java.awt.*;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class MultiplayerGameState extends State {

    private static RemoteWorld world;
    private static Client client;
    private Kryo kryo;
    private static String worldData;
    private NetworkingThread networking = new NetworkingThread();
    private Thread networkThread ;
    private static Boolean displayDebug = false;
    private static Boolean displayAdvancedDebug = false;
    private static UUID uuid;
    private static Handler handler;
    private static HashMap<UUID, Entity> entityHashMap = new HashMap<>();
    private static Boolean worldChanged = false;
    private Properties p;
    private static boolean save = false, load = false, offline = false, shutdown = false;
    private Animation saveIcon, loadIcon, offlineIcon, shutdownIcon;
    private int saveCount = 0, loadCount = 0;
    private static int dimensionID;

    private void init() {
        try {
            loadUUID();
            if(p == null) {
                uuid = UUID.randomUUID();
                p = new Properties();
                p.setUuid(uuid.toString());
                saveUUID();
            }

            client = new Client(65536, 32768);
            client.start();
            kryo = client.getKryo();
            kryo.register(BasicRequest.class);
            kryo.register(BasicResponse.class);
            kryo.register(Pos.class);
            kryo.register(UUIDPos.class);
            kryo.register(EntityPKG.class);
            InetAddress address = client.discoverHost(54777, 5000);
            client.connect(5000, address.getHostAddress(), 54555,54777);
            client.addListener(new Listener(handler));

            BasicRequest request = new BasicRequest();
            request.text = "CONNECT";
            request.data = uuid.toString();
            client.sendTCP(request);

            saveIcon = new Animation(350, Assets.saveAnim, true);
            loadIcon = new Animation(100, Assets.loadingAnim, true);
            offlineIcon = new Animation(1000, Assets.offlineAnim, true);
            shutdownIcon = new Animation(1000, Assets.shutdownAnim, true);
        } catch (IOException e) {
            System.out.println("Could not connect to a Server");
        }

    }

    public MultiplayerGameState(Handler handler) {
        super(handler);
        this.handler = handler;
        init();
        world = new RemoteWorld(handler);
        while(worldData == null) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        world.loadWorld(worldData);
        handler.setWorld(world);

        networking.setClient(client);
        networking.setHandler(handler);
        networking.setPlayer(handler.getWorld().getEntityManager().getPlayer());
        networkThread = new Thread(networking);
        networkThread.start();
    }

    @Override
    public void tick() {
        if(worldChanged) world.loadWorld(worldData);
        //ticking World Entities
        world.tick();
        //ticking Server Entities
        Iterator it = entityHashMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            Entity e = (Entity) pair.getValue();
            e.tick();
        }
        if(save){
            saveIcon.tick();
            saveCount++;
        }
        if(saveCount > 120) {
            saveCount = 0;
            save = false;
        }
        if(load) {
            loadIcon.tick();
            loadCount++;
        }
        if(loadCount > 200) {
            loadCount = 0;
            load = false;
        }
        if(offline) {
            offlineIcon.tick();
        }
        if(shutdown) {
            shutdownIcon.tick();
        }
    }

    @Override
    public void render(Graphics g) {
            //Rendering World Entities
            world.render(g);
            if(displayDebug) {
                Iterator it = entityHashMap.entrySet().iterator();
                while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                Entity e = (Entity) pair.getValue();

                    Rectangle r = e.getBounds();
                    Color c = g.getColor();
                    g.setColor(Color.GREEN);
                    g.drawRect((int) r.getX()  - (int) world.getHandler().getGameCamera().getxOffset(), (int) r.getY() - (int) world.getHandler().getGameCamera().getyOffset(), r.width, r.height );
                    g.setColor(c);
                }
            }

            if(handler.getKeyManager().debug) {
                try {
                    displayDebug = !displayDebug;
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                }
            }
            if(handler.getKeyManager().advancedDebug) {
                try {
                    displayAdvancedDebug = !displayAdvancedDebug;
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                }
            }

            if(displayDebug) {
                int x = (int) world.getEntityManager().getPlayer().getX();
                int y = (int) world.getEntityManager().getPlayer().getY();
                int width = world.getEntityManager().getPlayer().getWidth();
                int height = world.getEntityManager().getPlayer().getHeight();
                Text.drawString(g, "X:  " + x, 10, 12, false, Color.WHITE, Assets.font15);
                Text.drawString(g, "Y:  " + y, 10, 24, false, Color.WHITE, Assets.font15);
                Text.drawString(g, "HP: " +world.getEntityManager().getPlayer().getHealth(), 10, 36, false, Color.WHITE, Assets.font15);
                Text.drawString(g, "COLIDE E: "+world.getEntityManager().getPlayer().checkEntityCollisions(world.getEntityManager().getPlayer().getxMove(), world.getEntityManager().getPlayer().getyMove()), 10, 48, false, Color.WHITE, Assets.font15);
                Text.drawString(g, "COLIDE T: "+world.getEntityManager().getPlayer().collisionWithTile(x+ (int) world.getEntityManager().getPlayer().getxMove(),  y+ (int) world.getEntityManager().getPlayer().getyMove()), 10, 60, false, Color.WHITE, Assets.font15);
                if(uuid != null) Text.drawString(g, "UUID: "+uuid.toString(), 10, 72, false, Color.WHITE, Assets.font15);
                Text.drawString(g, "FPS :"+Game.getFPS()+"/60", 10, 84,false, Color.white, Assets.font15);
                Text.drawString(g, "Dimension: "+getDimensionID(), 10,96,false, Color.white, Assets.font15);
                Text.drawString(g, "Connected: "+(!offline), 10,108,false, Color.white, Assets.font15);

                Color c = g.getColor();
                //43517c77-a253-4014-860c-f3b9392798f3
                g.setColor(Color.CYAN);
                g.drawRect(x  - (int) world.getHandler().getGameCamera().getxOffset(), y - (int) world.getHandler().getGameCamera().getyOffset(), width, height );
                g.setColor(Color.red);
                g.drawRect(x  - (int) world.getHandler().getGameCamera().getxOffset() + world.getEntityManager().getPlayer().getBounds().x, y - (int) world.getHandler().getGameCamera().getyOffset() + world.getEntityManager().getPlayer().getBounds().y, world.getEntityManager().getPlayer().getBounds().width, world.getEntityManager().getPlayer().getBounds().height);

                Iterator it = MultiplayerGameState.getEntityHashMap().entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();
                    Entity e = (Entity) pair.getValue();
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setColor(Color.CYAN);
                    g2.drawRect((int) e.getX()  - (int) world.getHandler().getGameCamera().getxOffset(), (int) e.getY() - (int) world.getHandler().getGameCamera().getyOffset(), e.getWidth(), e.getHeight());
                    g2.setColor(Color.green);
                    if(e.isSolid()) g2.setColor(Color.red);
                    g2.drawRect((int) e.getX()  - (int) world.getHandler().getGameCamera().getxOffset() + e.getBounds().x, (int) e.getY() - (int) world.getHandler().getGameCamera().getyOffset() + e.getBounds().y, e.getBounds().width, e.getBounds().height);
                }
                g.setColor(c);
            }
        if(save) {
            g.drawImage(saveIcon.getCurrentFrame(), 685,10, 35, 37,null);
        }
        if(load) {
            g.drawImage(loadIcon.getCurrentFrame(), 685,10, 35, 37,null);
        }
        if(offline) {
            if(shutdown) {
                g.drawImage(shutdownIcon.getCurrentFrame(), 685,10,45,45,null);
            } else {
                g.drawImage(offlineIcon.getCurrentFrame(), 685, 10, 45, 45, null);
            }
        }
    }

    public static void setWorldData(String worldData1) {
        if(worldData != null) {
            worldData = worldData1;
            world.loadWorld(worldData);
            return;
        }
        worldData = worldData1;

    }

    private void loadUUID() {
        try {
            String path = System.getProperty("user.dir");
            path = path + "\\properties.dat";
            FileInputStream fis = null;
            fis = new FileInputStream(path);
            XMLDecoder xml = new XMLDecoder(fis);
            System.out.println("Loading...: " + path);
            Properties p1 = (Properties) xml.readObject();
            p = p1;
            uuid = UUID.fromString(p.getUuid());
            xml.close();
            fis.close();
            System.out.println("Loaded.");
        } catch (FileNotFoundException e) {
            System.out.println("EXCEPTION: " + e.getMessage());
            System.out.println("This should only occur once.");
        } catch (IOException e) {
            System.out.println("EXCEPTION: " + e.getMessage());
        }
    }

    private void saveUUID() {
        try {
            String path = System.getProperty("user.dir");
            FileOutputStream fos = new FileOutputStream(path + "\\" + "properties" + ".dat");
            XMLEncoder xml = new XMLEncoder(fos);
            xml.writeObject(p);
            xml.close();
            fos.close();
            System.out.println("Multiplayer Properties saved.");
        } catch (IOException e) {
            System.out.println("An Error occured while saving Multiplayer Properties.");
        }
        MultiplayerGameState.setUUID(UUID.randomUUID());
    }


    public void handleEntityHit(String uuid, int amount) {
        BasicRequest request = new BasicRequest();
        request.text = "HIT";
        request.data = uuid+"#"+amount;
        client.sendTCP(request);
    }
    public static void handlePlayerDead() {
        YouDiedState diedState = new YouDiedState(handler, displayDebug, entityHashMap, uuid);
        State.setState(diedState);
    }
    public static HashMap<UUID, Entity> getEntityHashMap() {
        return entityHashMap;
    }
    public static void setUUID(UUID uuid1) {
        uuid = uuid1;
    }
    public static UUID getUUID() {
        return uuid;
    }
    public static Client getClient() {
        return client;
    }
    public static void triggerSave() {
        save = true;
    }
    public static void triggerLoad() {
        load = true;
    }
    public static void triggerOffline() {
        offline = true;
    }
    public static void triggerShutdown() {
        shutdown = true;
    }
    public static Boolean getAdvancedDebug() {
        return displayAdvancedDebug;
    }
    public static int getDimensionID() {
        return dimensionID;
    }
    public static void setDimensionID(int dimension) {
        dimensionID = dimension;
    }
    public static RemoteWorld getWorld() {
        return world;
    }
}
