package dev.codenmore.tilegame.worlds;

import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.Entity;
import dev.codenmore.tilegame.entities.EntityManager;
import dev.codenmore.tilegame.entities.creatures.Player;
import dev.codenmore.tilegame.entities.statics.*;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.gfx.Text;
import dev.codenmore.tilegame.items.Item;
import dev.codenmore.tilegame.items.ItemManager;
import dev.codenmore.tilegame.objects.BasicRequest;
import dev.codenmore.tilegame.states.MultiplayerGameState;
import dev.codenmore.tilegame.tiles.Tile;
import dev.codenmore.tilegame.utils.Utils;

import java.awt.*;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class RemoteWorld extends World {

    private Handler handler;
    private int width, height;
    private int spawnX, spawnY;
    private int[][] tiles;
    //Entities
    private EntityManager entityManager;
    // Item
    private ItemManager itemManager;

    public RemoteWorld(Handler handler) {
        super(handler);
        this.handler = handler;
        entityManager = new EntityManager(handler, new Player(handler, 100, 100));
        itemManager = new ItemManager(handler);
    }

    public void tick(){
        Iterator it = MultiplayerGameState.getEntityHashMap().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            Entity e = (Entity) pair.getValue();
            if(e.equals(this)) continue;
            if(!entityManager.getEntities().contains(e))
                entityManager.addEntity(e);
        }
        itemManager.tick();
        entityManager.tick();
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                getTile(x,y).tick();
            }
        }
    }

    public void render(Graphics g){
        int xStart = (int) Math.max(0, handler.getGameCamera().getxOffset() / Tile.TILEWIDTH);
        int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth()) / Tile.TILEWIDTH + 1);
        int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset() / Tile.TILEHEIGHT);
        int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset() + handler.getHeight()) / Tile.TILEHEIGHT + 1);

        for(int y = yStart;y < yEnd;y++){
            for(int x = xStart;x < xEnd;x++){
                getTile(x, y).render(g, (int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()),
                        (int) (y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset()));
                if(MultiplayerGameState.getAdvancedDebug()) {
                    Text.drawString(g, tiles[x][y]+"", (int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()+ getTile(x,y).TILEWIDTH/4),
                            (int) (y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset() + getTile(x,y).TILEHEIGHT/4), false, Color.RED, Assets.font15);
                    g.setColor(Color.white);
                    g.drawRect((int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()),
                            (int) (y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset()), Tile.TILEWIDTH, Tile.TILEHEIGHT);
                }
            }
        }
        // Items
        itemManager.render(g);
        //Entities
        entityManager.render(g);
    }

    public Tile getTile(int x, int y){
        if(x < 0 || y < 0 || x >= width || y >= height)
            return Tile.grassTile;

        Tile t = Tile.tiles[tiles[x][y]];
        if(t == null)
            return Tile.dirtTile;
        return t;
    }

    public void loadWorld(String data){
        String[] tokens = data.split("\\s+");
        width = Utils.parseInt(tokens[0]);
        height = Utils.parseInt(tokens[1]);
        spawnX = Utils.parseInt(tokens[2]);
        spawnY = Utils.parseInt(tokens[3]);
        entityManager.getPlayer().setX(spawnX);
        entityManager.getPlayer().setY(spawnY);
        tiles = new int[width][height];
        System.out.println("World: ["+width+"|"+height+"] Spawn: ["+spawnX+"|"+spawnY+"]");
        int i = 0;
        for(int y = 0;y < height;y++){
            for(int x = 0;x < width;x++){
                tiles[x][y] = Utils.parseInt(tokens[(x + y * width) + 4]);
                i++;
            }
        }
        BasicRequest request = new BasicRequest();
        request.text = "STATS?";
        MultiplayerGameState.getClient().sendTCP(request);
    }

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public ItemManager getItemManager() {
        return itemManager;
    }

    public void setItemManager(ItemManager itemManager) {
        this.itemManager = itemManager;
    }
}
