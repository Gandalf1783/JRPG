package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon114 extends Tile {
    public Dungeon114(int id) {
        super(Assets.dungeon114, id);
    }
}
