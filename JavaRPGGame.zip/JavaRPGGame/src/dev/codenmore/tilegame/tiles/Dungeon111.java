package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon111 extends Tile {
    public Dungeon111( int id) {
        super(Assets.dungeon111,id);
    }
}
