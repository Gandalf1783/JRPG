package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon116 extends Tile {
    public Dungeon116(int id) {
        super(Assets.dungeon116, id);
    }
}
