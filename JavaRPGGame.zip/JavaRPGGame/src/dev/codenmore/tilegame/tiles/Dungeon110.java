package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon110 extends Tile {
    public Dungeon110(int id) {
        super(Assets.dungeon110, id);
    }

}
