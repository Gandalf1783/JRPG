package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class SandTile extends Tile {

    public SandTile(int id) {
        super(Assets.sand, id);
    }

    @Override
    public boolean isSolid() {
        return false;
    }
}
