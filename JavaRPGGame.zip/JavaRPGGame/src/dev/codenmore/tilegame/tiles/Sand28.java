package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Sand28 extends Tile {

    private Animation animation = new Animation(300, Assets.sand28, true);

    public Sand28(int id) {
        super(Assets.sand28[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
