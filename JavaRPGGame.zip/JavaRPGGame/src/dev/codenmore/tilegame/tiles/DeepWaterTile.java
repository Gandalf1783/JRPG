package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class DeepWaterTile extends Tile {

    private Animation animation = new Animation(300, Assets.deepWater, true);

    public DeepWaterTile( int id) {
        super(Assets.deepWater[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }

}
