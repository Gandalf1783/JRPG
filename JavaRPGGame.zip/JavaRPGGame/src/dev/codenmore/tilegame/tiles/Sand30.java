package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Sand30 extends Tile {
    private Animation animation = new Animation(300, Assets.sand30, true);

    public Sand30(int id) {
        super(Assets.sand30[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
