package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

public class Sand23 extends Tile {

    private Animation animation = new Animation(300, Assets.sand23, true);

    public Sand23(int id) {
        super(Assets.sand23[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
