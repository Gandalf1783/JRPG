package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Sand29 extends Tile {

    private Animation animation = new Animation(300, Assets.sand29, true);

    public Sand29(int id) {
        super(Assets.sand29[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
