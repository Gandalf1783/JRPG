package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon117 extends Tile {
    public Dungeon117(int id) {
        super(Assets.dungeon117, id);
    }
}
