package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Water14 extends Tile {

    private Animation animation = new Animation(300, Assets.water14, true);

    public Water14(int id) {
        super(Assets.water14[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
