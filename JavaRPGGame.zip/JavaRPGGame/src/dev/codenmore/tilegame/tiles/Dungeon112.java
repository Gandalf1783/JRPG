package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon112 extends Tile {
    public Dungeon112(int id) {
        super(Assets.dungeon112, id);
    }
}
