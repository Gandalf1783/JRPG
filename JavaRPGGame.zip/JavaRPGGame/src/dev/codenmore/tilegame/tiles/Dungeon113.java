package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon113 extends Tile {
    public Dungeon113(int id) {
        super(Assets.dungeon113, id);
    }
}
