package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Sand35 extends Tile {
    private Animation animation = new Animation(350, Assets.sand35, true);

    public Sand35(int id) {
        super(Assets.sand35[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
