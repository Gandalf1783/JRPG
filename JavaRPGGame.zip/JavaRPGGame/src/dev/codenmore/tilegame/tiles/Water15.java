package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Water15 extends Tile {

    private Animation animation = new Animation(300, Assets.water15, true);

    public Water15(int id) {
        super(Assets.water15[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
