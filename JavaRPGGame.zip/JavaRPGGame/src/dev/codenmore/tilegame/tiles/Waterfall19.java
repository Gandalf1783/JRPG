package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Waterfall19 extends Tile {

    private Animation animation;

    public Waterfall19(int id) {
        super(Assets.water19[0], id);
        animation = new Animation(220, Assets.water19, true);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
