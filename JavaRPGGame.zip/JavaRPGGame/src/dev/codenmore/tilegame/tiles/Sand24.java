package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

public class Sand24 extends Tile {

    private Animation animation = new Animation(300, Assets.sand24, true);

    public Sand24(int id) {
        super(Assets.sand24[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
    
}
