package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Dungeon115 extends Tile {
    public Dungeon115(int id) {
        super(Assets.dungeon115, id);
    }
}
