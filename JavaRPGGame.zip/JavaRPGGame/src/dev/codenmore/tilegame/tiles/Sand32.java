package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

public class Sand32 extends Tile {
    private Animation animation = new Animation(320, Assets.sand32, true);

    public Sand32(int id) {
        super(Assets.sand32[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
