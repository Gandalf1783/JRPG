package dev.codenmore.tilegame.tiles;

import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.image.BufferedImage;

public class Sand22 extends Tile {

    private Animation animation = new Animation(300, Assets.sand22, true);

    public Sand22(int id) {
        super(Assets.sand22[0], id);
    }

    @Override
    public void tick() {
        animation.tick();
        texture = animation.getCurrentFrame();
    }
}
