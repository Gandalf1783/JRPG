package dev.codenmore.tilegame.threads;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import javax.sound.sampled.AudioInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URISyntaxException;

public class AudioThread implements Runnable {

    @Override
    public void run() {
    }

}
