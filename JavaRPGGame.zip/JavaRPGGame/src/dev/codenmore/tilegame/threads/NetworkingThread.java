package dev.codenmore.tilegame.threads;

import com.esotericsoftware.kryonet.Client;
import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.creatures.Player;
import dev.codenmore.tilegame.objects.Pos;
import dev.codenmore.tilegame.states.MultiplayerGameState;

import java.nio.BufferOverflowException;

public class NetworkingThread implements Runnable {

    private Handler handler;
    private Player p;
    private Pos pos = new Pos();
    private Client client;

    public NetworkingThread() {
    }

    @Override
    public void run() {
        while (true) {
                pos.setX(handler.getWorld().getEntityManager().getPlayer().getX());
                pos.setY(handler.getWorld().getEntityManager().getPlayer().getY());
                pos.setDimensionID(MultiplayerGameState.getDimensionID());
                client.sendUDP(pos);
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
            } catch(BufferOverflowException e) {
               System.out.println("[FATAL] BUFFER OVERFLOW");
            }

        }
    }

    public void setClient(Client client) {
        this.client = client;
    }
    public void setHandler(Handler handler) {
        this.handler = handler;
    }
    public void setPlayer(Player p) {
        this.p = p;
    }
}
