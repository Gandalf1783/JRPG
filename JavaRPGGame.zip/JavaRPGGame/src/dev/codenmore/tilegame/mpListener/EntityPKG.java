package dev.codenmore.tilegame.mpListener;

public class EntityPKG {
    public String text;
    public int x, y, dimensionID;
    public String type;
    public int health;
    public String uuid;
}

