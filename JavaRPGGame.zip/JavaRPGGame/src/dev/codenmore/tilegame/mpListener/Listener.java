package dev.codenmore.tilegame.mpListener;

import com.esotericsoftware.kryonet.Connection;
import com.sun.org.apache.xpath.internal.operations.Mult;
import dev.codenmore.tilegame.Game;
import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.Entity;
import dev.codenmore.tilegame.entities.creatures.RemotePlayer;
import dev.codenmore.tilegame.entities.statics.Cactus;
import dev.codenmore.tilegame.objects.BasicRequest;
import dev.codenmore.tilegame.objects.BasicResponse;
import dev.codenmore.tilegame.objects.Pos;
import dev.codenmore.tilegame.objects.UUIDPos;
import dev.codenmore.tilegame.states.MultiplayerGameState;
import sun.applet.Main;

import java.util.Map;
import java.util.UUID;

@SuppressWarnings("ALL")
public class Listener extends com.esotericsoftware.kryonet.Listener {

    private Handler handler;

    public Listener(Handler handler) {
        this.handler = handler;
    }

    @Override
    public void received(Connection connection, Object o) {
        if(o instanceof BasicResponse) {
            BasicResponse response = (BasicResponse) o;
            BasicRequest request = new BasicRequest();
            if(response.text.equalsIgnoreCase("VER0")) {
                request.text = "VER0";
                request.data = Game.getVersion();
                connection.sendTCP(request);
            }
            if(response.text.equalsIgnoreCase("VER1")) {
                request.text = "VER1";
                request.data = Game.getNetVersion();
                connection.sendTCP(request);
            }

            if(response.text.equalsIgnoreCase("WORLD")) {
                MultiplayerGameState.setWorldData(response.data);
            }
            if(response.text.equalsIgnoreCase("PLAYERADD")) {
                String data = response.data;
                String[] dataArray = data.split("#");
                String xPos = dataArray[0];
                String yPos = dataArray[1];
                String health = dataArray[2];
                UUID uuid = UUID.fromString(dataArray[3]);
                RemotePlayer p = new RemotePlayer(handler, Float.parseFloat(xPos), Float.parseFloat(yPos));
                p.setHealth(Integer.parseInt(health));
                p.setUUID(uuid);
                MultiplayerGameState.getEntityHashMap().put(uuid, p);
            }
            if(response.text.equalsIgnoreCase("NEXT")) {
                if(response.data.equals("1")) {
                    request.text = "LOGIN?";
                    request.data = MultiplayerGameState.getUUID().toString();
                    connection.sendTCP(request);
                    return;
                } else if(response.data.equals("2")) {
                    request.text = "ENTITIES?";
                    connection.sendTCP(request);
                    return;
                }
            }
            if(response.text.equalsIgnoreCase("UUID")) {
                if(response.data.equalsIgnoreCase("IN_USE")) {
                    System.out.println("UUID already connected to the Server. Please use an other computer for this.");
                    System.exit(4);
                }
            }
            if(response.text.equalsIgnoreCase("DIE")) {
                System.out.println("UUID: "+request.data);
                if(MultiplayerGameState.getUUID().equals(UUID.fromString(response.data))) {
                    handler.getWorld().getEntityManager().getPlayer().setHealth(0);
                    handler.getWorld().getEntityManager().getPlayer().die();
                    return;
                } else {
                    if(MultiplayerGameState.getEntityHashMap().containsKey(UUID.fromString(response.data))) {
                        MultiplayerGameState.getEntityHashMap().get(UUID.fromString(response.data)).die();
                        System.out.println("[DEAD] Entity with UUID "+response.data+" has died!");
                    }
                }
                try {
                    MultiplayerGameState.getEntityHashMap().get(getKeyFromValue(MultiplayerGameState.getEntityHashMap(), response.data)).die();
                } catch (NullPointerException e) {
                }
                MultiplayerGameState.getEntityHashMap().remove(UUID.fromString(response.data));
            }
            if(response.text.equalsIgnoreCase("HIT")) {
                String[] data = response.data.split("#");
                if(MultiplayerGameState.getUUID().equals(UUID.fromString(data[0]))) {
                    handler.getWorld().getEntityManager().getPlayer().hurt(Integer.parseInt(data[1]));
                    return;
                }
                try {
                    MultiplayerGameState.getEntityHashMap().get(getKeyFromValue(MultiplayerGameState.getEntityHashMap(), data[0])).hurt(Integer.parseInt(data[1]));
                } catch (NullPointerException e) {
                }
            }
            if(response.text.equalsIgnoreCase("DISCONNECT")) {
                System.out.println("DISCONNECT: "+response.data);
                try {
                    UUID uuid = UUID.fromString(response.data);
                    MultiplayerGameState.getEntityHashMap().get(uuid).setActive(false);
                } catch(IllegalArgumentException e) {
                }
            }
            if(response.text.equalsIgnoreCase("HEALTH")) {
                String[] data = response.data.split("#");
                if(MultiplayerGameState.getUUID().equals(UUID.fromString(data[0]))) {
                    handler.getWorld().getEntityManager().getPlayer().setHealth(Integer.parseInt(data[1]));
                } else {
                    if(MultiplayerGameState.getEntityHashMap().get(UUID.fromString(data[0])) == null) return;
                    MultiplayerGameState.getEntityHashMap().get(UUID.fromString(data[0])).setHealth(Integer.parseInt(data[1]));
                }
            }
            if(response.text.equalsIgnoreCase("SAVE")) {
                MultiplayerGameState.triggerSave();
            }
            if(response.text.equalsIgnoreCase("LOAD")) {
                MultiplayerGameState.triggerLoad();
            }
            if(response.text.equalsIgnoreCase("SHUTDOWN")) {
                MultiplayerGameState.triggerOffline();
                MultiplayerGameState.triggerShutdown();
            }
        }

        if(o instanceof UUIDPos) {
            UUIDPos uPos = (UUIDPos) o;
            if(MultiplayerGameState.getEntityHashMap().get(UUID.fromString(uPos.uuid)) == null) {
                if(MultiplayerGameState.getDimensionID() != uPos.p.getDimensionID()) {
                    MultiplayerGameState.setDimensionID(uPos.p.getDimensionID());
                }
                return;
            }
            if(MultiplayerGameState.getDimensionID() != uPos.p.getDimensionID()) return;
            MultiplayerGameState.getEntityHashMap().get(UUID.fromString(uPos.uuid)).setX(uPos.p.getX());
            MultiplayerGameState.getEntityHashMap().get(UUID.fromString(uPos.uuid)).setY(uPos.p.getY());
        }
        if(o instanceof EntityPKG) {
            EntityPKG ePKG = (EntityPKG) o;
            Pos p = new Pos();
            p.setY(ePKG.y);
            p.setX(ePKG.x);
            p.setDimensionID(ePKG.dimensionID);
            int health = ePKG.health;
            String uuid = ePKG.uuid;
            if(ePKG.type.equalsIgnoreCase("Cactus")) {
                Cactus c = new Cactus(handler, UUID.fromString(uuid), p.getX(), p.getY(), 64,64);
                c.setHealth(health);
                MultiplayerGameState.getEntityHashMap().put(UUID.fromString(uuid), c);
                MultiplayerGameState.getEntityHashMap().get(UUID.fromString(uuid)).setDimensionID(p.getDimensionID());
            } else {
                System.out.println("Not found: Entity Type: "+ePKG.type);
            }
        }
    }

    @Override
    public void disconnected(Connection connection) {
        MultiplayerGameState.triggerOffline();
    }

    public static Object getKeyFromValue(Map hm, Object value) {
        for (Object o : hm.keySet()) {
            if (hm.get(o).equals(value)) {
                return o;
            }
        }
        return null;
    }
}
