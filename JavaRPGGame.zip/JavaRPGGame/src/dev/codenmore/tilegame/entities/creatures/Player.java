package dev.codenmore.tilegame.entities.creatures;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.*;

import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.Entity;
import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.inventory.Inventory;
import dev.codenmore.tilegame.objects.BasicRequest;
import dev.codenmore.tilegame.states.MultiplayerGameState;
import dev.codenmore.tilegame.states.State;
import dev.codenmore.tilegame.states.YouDiedState;

public class Player extends Creature {
	
	//Animations
	private Animation animDown, animUp, animLeft, animRight, animDied;
	private Animation animAttackDown, animAttackUp, animAttackLeft, animAttackRight;
	private Boolean attackDown, attackUp, attackLeft, attackRight;
	// Inventory
	private Inventory inventory;
	private Boolean died;

	public Player(Handler handler, float x, float y) {
		super(handler, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
		
		bounds.x = 22;
		bounds.y = 44;
		bounds.width = 19;
		bounds.height = 19;
		
		//Animatons
		animDown = new Animation(50, Assets.player_down, true);
		animUp = new Animation(50, Assets.player_up, true);
		animLeft = new Animation(50, Assets.player_left, true);
		animRight = new Animation(50, Assets.player_right, true);
		animAttackDown = new Animation(100, Assets.player_attackDown, false);
		animAttackLeft = new Animation(100, Assets.player_attackLeft, false);
		animAttackRight = new Animation(100, Assets.player_attackRight,false);
		animAttackUp = new Animation(100, Assets.player_attackUp, false);
		animDied = new Animation(250, Assets.player_die, false);
		//Attack Animations
		attackDown = false;
		attackLeft = false;
		attackRight = false;
		attackUp = false;
		died = false;
		inventory = new Inventory(handler);
	}

	@Override
	public void tick() {
		//Animations
		if(active) {
			animDown.tick();
			animUp.tick();
			animRight.tick();
			animLeft.tick();
			animAttackUp.tick();
			animAttackRight.tick();
			animAttackLeft.tick();
			animAttackDown.tick();
			//Movement
			getInput();
			move();
			// Attack
			checkAttacks();
			// Inventory
			inventory.tick();
		}
		if(attackUp && animAttackUp.getHasPlayed()) {
			attackUp = false;
		}
		if(attackRight && animAttackRight.getHasPlayed()) {
			attackRight = false;
		}
		if(attackLeft && animAttackLeft.getHasPlayed()) {
			attackLeft = false;
		}
		if(attackDown && animAttackDown.getHasPlayed()) {
			attackDown = false;
		}
		handler.getGameCamera().centerOnEntity(this);
	}
	
	private void checkAttacks(){
		if(attackDown || attackLeft || attackRight || attackUp)
			return;
		
		if(inventory.isActive())
			return;

		Rectangle cb = getCollisionBounds(0, 0);
		Rectangle ar = new Rectangle();
		int arSize = 20;
		ar.width = arSize;
		ar.height = arSize;
		if(handler.getKeyManager().aUp){
			attackUp = true;
			ar.x = cb.x + cb.width / 2 - arSize / 2;
			ar.y = cb.y - arSize;
			if(animAttackUp.getHasPlayed())
				animAttackUp = new Animation(90, Assets.player_attackUp, false);
		}else if(handler.getKeyManager().aDown){
			attackDown = true;
			ar.x = cb.x + cb.width / 2 - arSize / 2;
			ar.y = cb.y + cb.height;
			if(animAttackDown.getHasPlayed())
				animAttackDown = new Animation(90, Assets.player_attackDown, false);
		}else if(handler.getKeyManager().aLeft){
			attackLeft = true;
			ar.x = cb.x - arSize;
			ar.y = cb.y + cb.height / 2 - arSize / 2;
			if(animAttackLeft.getHasPlayed()) {
				animAttackLeft = new Animation(90, Assets.player_attackLeft, false);
			}
		}else if(handler.getKeyManager().aRight){
			attackRight = true;
			ar.x = cb.x + cb.width;
			ar.y = cb.y + cb.height / 2 - arSize / 2;
			if(animAttackRight.getHasPlayed())
				animAttackRight = new Animation(90, Assets.player_attackRight,false);
		}else{
			return;
		}


		for(Entity e : handler.getWorld().getEntityManager().getEntities()){
			if(e.equals(this))
				continue;
			if(e.getCollisionBounds(0, 0).intersects(ar)){
				if(State.getState() == handler.getGame().multiplayerGameState) { // IF Multiplayer, let the Server handle everything.
					if(MultiplayerGameState.getEntityHashMap().containsValue(e)) {
						((MultiplayerGameState) State.getState()).handleEntityHit(getKeyFromValue(MultiplayerGameState.getEntityHashMap(), e).toString(), 1);
					}
				} else {  // IF Singleplayer, just hurt the entity!
					e.hurt(1);
				}
			}
		}
	}
	
	@Override
	public void die(){
		died = true;
		if(State.getState() == handler.getGame().multiplayerGameState){
			System.out.println("You died.");
			MultiplayerGameState.handlePlayerDead();
			active = false;
		}
	}
	
	private void getInput(){
		xMove = 0;
		yMove = 0;

		if(inventory.isActive())
			return;
		
		if(handler.getKeyManager().up)
			yMove = -speed;
		if(handler.getKeyManager().down)
			yMove = speed;
		if(handler.getKeyManager().left)
			xMove = -speed;
		if(handler.getKeyManager().right)
			xMove = speed;
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
	}
	
	public void postRender(Graphics g){
		inventory.render(g);
	}
	
	private BufferedImage getCurrentAnimationFrame(){
		if(died) {
			return animDied.getCurrentFrame();
		} else if(attackUp) {
			return animAttackUp.getCurrentFrame();
		} else if(attackRight) {
			return animAttackRight.getCurrentFrame();
		} else if(attackLeft) {
			return animAttackLeft.getCurrentFrame();
		} else if(attackDown) {
			return animAttackDown.getCurrentFrame();
		} else if(xMove < 0){
			return animLeft.getCurrentFrame();
		}else if(xMove > 0){
			return animRight.getCurrentFrame();
		}else if(yMove < 0){
			return animUp.getCurrentFrame();
		} else if(yMove > 0) {
			return animDown.getCurrentFrame();
		} else {
			return Assets.player_stand;
		}
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public static Object getKeyFromValue(Map hm, Object value) {
		for (Object o : hm.keySet()) {
			if (hm.get(o).equals(value)) {
				return o;
			}
		}
		return null;
	}

	@Override
	public void setHealth(int health) {
		super.setHealth(health);
		if(health <= 0) {
			BasicRequest request = new BasicRequest();
			request.text = "DIE";
			request.data = MultiplayerGameState.getUUID().toString();
			MultiplayerGameState.getClient().sendTCP(request);
		}

	}
}
