package dev.codenmore.tilegame.entities.creatures;

import com.sun.org.apache.xpath.internal.operations.Mult;
import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.gfx.Animation;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.inventory.Inventory;
import dev.codenmore.tilegame.objects.BasicRequest;
import dev.codenmore.tilegame.states.MultiplayerGameState;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Map;
import java.util.UUID;

public class RemotePlayer extends Creature {

    //Animations
    private Animation animDown, animUp, animLeft, animRight, animDie;
    // Attack timer
    private long lastAttackTimer, attackCooldown = 800, attackTimer = attackCooldown;
    // Inventory
    private Inventory inventory;
    private static UUID uuid;
    private Boolean died;

    public RemotePlayer(Handler handler, float x, float y) {
        super(handler, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_WIDTH);
        bounds.x = 22;
        bounds.y = 44;
        bounds.width = 19;
        bounds.height = 19;

        //Animatons
        animDown = new Animation(80, Assets.remoteplayer_down, true);
        animUp = new Animation(90, Assets.remoteplayer_up, true);
        animLeft = new Animation(100, Assets.remoteplayer_left, true);
        animRight = new Animation(100, Assets.remoteplayer_right, true);
        animDie = new Animation(250, Assets.remoteplayer_die, false);
        died = false;
        inventory = new Inventory(handler);
    }

    @Override
    public void tick() {
        if(died || active == false) {
            if(animDie.getHasPlayed()) {
                MultiplayerGameState.getEntityHashMap().remove(uuid);
                active = false;
                return;
            }
            animDie.tick();
            return;
        }
        //Animations
        animDown.tick();
        animUp.tick();
        animRight.tick();
        animLeft.tick();
        getInput();
        move();
        inventory.tick();
    }

    private void getInput(){

    }

    @Override
    public void hurt(int amt) {
        BasicRequest request = new BasicRequest();
        request.text = "HIT";
        request.data = getKeyFromValue(MultiplayerGameState.getEntityHashMap(), this).toString()+"#"+amt;
        MultiplayerGameState.getClient().sendTCP(request);
        super.hurt(amt);
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
    }

    @Override
    public void die() {
        System.out.println("[REMOTE PLAYER] DEAD.");
        BasicRequest request = new BasicRequest();
        request.text = "DEAD";
        request.data = uuid.toString();
        MultiplayerGameState.getClient().sendTCP(request);
        died = true;

    }

    private BufferedImage getCurrentAnimationFrame(){
        if(died) {
            return animDie.getCurrentFrame();
        } else if(xMove < 0){
            return animLeft.getCurrentFrame();
        }else if(xMove > 0){
            return animRight.getCurrentFrame();
        }else if(yMove < 0){
            return animUp.getCurrentFrame();
        } else {
            return animDown.getCurrentFrame();
        }
    }

    public void setUUID(UUID uuid1) {
        uuid = uuid1;
    }

    public static Object getKeyFromValue(Map hm, Object value) {
        for (Object o : hm.keySet()) {
            if (hm.get(o).equals(value)) {
                return o;
            }
        }
        return null;
    }

    @Override
    public Boolean isSolid() {
        return false;
    }

}
