package dev.codenmore.tilegame.entities.statics;

import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.gfx.Assets;

import java.awt.*;
import java.util.UUID;

public class Sign203 extends StaticEntity {

    public Sign203(Handler handler, UUID uuid, float x, float y, int width, int height) {
        super(handler, uuid, x, y, width, height, false);
    }

    @Override
    public void tick() {
    }
    @Override
    public void render(Graphics g) {
        g.drawImage(Assets.sign203, (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
    }
}
