package dev.codenmore.tilegame.entities.statics;

import dev.codenmore.tilegame.Handler;
import dev.codenmore.tilegame.entities.Entity;
import dev.codenmore.tilegame.states.MultiplayerGameState;

import java.awt.*;
import java.lang.invoke.MutableCallSite;
import java.util.UUID;

public abstract class StaticEntity extends Entity {

	private UUID uuid = UUID.randomUUID();
	private Boolean solid = false;

	public StaticEntity(Handler handler, UUID uuid, float x, float y, int width, int height, boolean solid){
		super(handler, x, y, width, height);
		this.uuid = uuid;
		this.solid = solid;
	}

	public void hurt(int amt) {
		super.hurt(amt);
	}

	public void die() {
		active = false;
		if(MultiplayerGameState.getEntityHashMap().containsValue(this))
			System.out.println("UUID DIED: "+this.uuid);
			MultiplayerGameState.getEntityHashMap().remove(this.uuid);
		}
	public Boolean isSolid() { return solid;}

	@Override
	public Rectangle getBounds() {
		return this.bounds;
	}
}
